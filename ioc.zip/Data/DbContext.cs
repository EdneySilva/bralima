﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Data
{
    class DbContext : IRepositoryContext, IUnityOfWork
    {
        List<Func<object>> itens = new List<Func<object>>();

        public DbContext()
        {
            System.Diagnostics.Debug.Write("Gerou uma instância na requisição");
        }

        public void Add<T>(T item)
        {
            itens.Add(() => item);
        }

        public void Save()
        {
            System.Diagnostics.Debug.Write(itens);
        }
    }
}
