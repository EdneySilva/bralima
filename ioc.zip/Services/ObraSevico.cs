﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;
using WebApplication2.Models;

namespace WebApplication2.Services
{
    class ObraSevico : IObraServico
    {
        private readonly IUnityOfWork unitOfWork;
        private readonly IObraRepositorio obraRepositorio;

        public ObraSevico(IUnityOfWork unitOfWork, IObraRepositorio obraRepositorio)
        {
            this.unitOfWork = unitOfWork;
            this.obraRepositorio = obraRepositorio;
        }

        public void IniciarObra(string name)
        {
            obraRepositorio.AdicionarObra(new Obra
            {
                Name = name
            });
            unitOfWork.Save();
        }
    }
}
