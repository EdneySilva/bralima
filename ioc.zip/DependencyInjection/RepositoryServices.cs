﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Data;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class RepositoryServices
    {
        public static IServiceCollection AddAppRepositoryServices(this IServiceCollection services)
        {
            services.AddScoped<DbContext>();
            services.AddScoped<IRepositoryContext>((service) => service.GetService<DbContext>());
            services.AddScoped<IUnityOfWork>((service) => service.GetService<DbContext>());
            services.AddScoped<IObraRepositorio, ObraRepository>();
            return services;
        }
        
    }
}
